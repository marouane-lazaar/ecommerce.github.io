module.exports={
    MONGOURI:"mongodb+srv://amine:amine@cluster0.amew9.mongodb.net/<dbname>?retryWrites=true&w=majority"
}